"""
Planner Django app for cutting optimization backend.
"""

default_app_config = 'planner.apps.PlannerConfig'
